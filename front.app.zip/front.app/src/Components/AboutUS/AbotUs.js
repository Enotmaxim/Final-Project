import React, {Component} from 'react';
import './AboutUs.scss'

class AbotUs extends Component {
    render() {
        return (
            <div>
                hello second
            </div>
        );
    }
}

export default AbotUs;