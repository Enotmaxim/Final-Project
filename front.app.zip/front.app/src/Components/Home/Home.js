import React, {Component} from 'react';
import './Home.scss'
import point from "../../img/Body/background/grouper.png"
import one from "../../img/Body/complement/one.png"
import two from "../../img/Body/complement/two.png"
import three from "../../img/Body/complement/three.png"
import four from "../../img/Body/complement/four.png"
import slid from "../../img/Body/background/Testimonial.png"
import user1 from "../../img/Footer/user/user1.png"
import user2 from "../../img/Footer/user/user2.png"
import logotype from "../../img/Footer/Logo/Logo.png"
import fb from "../../img/Footer/Link/facebook.png"
import lk from "../../img/Footer/Link/linkedin.png"
import tw from "../../img/Footer/Link/twitter.png"




class Home extends Component {
        render() {
        return (
            <div>
                hello first
            </div>
        );
    }
}

export default Home;