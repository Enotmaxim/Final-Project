import React, {Component} from 'react';
import './Contact.scss'
class Contact extends Component {
    render() {
        return (
            <div>
                hello thirt
            </div>
        );
    }
}

export default Contact;