import React, {Component} from 'react';
import "./OurService.scss"
class OurService extends Component {
    render() {
        return (
            <div>
                hello four
            </div>
        );
    }
}

export default OurService;