import React, {Component} from 'react';

class NavBarMobile extends Component {
    render() {
        const {items} = this.props
        const NavigationBar = items.map((singleItem , index)=>
            (<li className="navigation-bar-mobile" key={index}><a href={`/${singleItem.toLowerCase()}`}>
                {singleItem.toUpperCase()}</a></li>))
        return (
            <ul className="navigation-bar-components-mmobile">
                {NavigationBar}
            </ul>
        );
    }
}

export default NavBarMobile;