import React, {Component} from 'react';
import './NavBar.scss'

class NavBar extends Component {

        return (
            <div>
                hello thirt
            </div>
        );
    }
}


export default NavBar;