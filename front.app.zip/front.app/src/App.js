import './App.scss';
import Home from "./Components/Home/Home";
import AboutUs from "./Components/AboutUS/AbotUs";
import Contact from "./Components/Contact/Contact";
import OurService from "./Components/OurService/OurService";
import { Route } from "react-router-dom";
import NavBar from "./Components/NavBar/Navbar";
import React from "react";


function App() {
    return (
        <div className="content">
      
            
        <div>
            <Route path="/home" render ={()=> <Home/>}/>
            <Route path="/about%us" render ={()=> <AboutUs/>}/>
            <Route path="/contact" render ={()=> <Contact/>}/>
            <Route path="/our%service" render ={()=> <OurService/>}/>
        </div>
        </div>
    )
    }

export default App;
